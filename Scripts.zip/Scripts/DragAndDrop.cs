using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DragAndDrop : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{

    private Vector3 originalPosition;

    public void OnBeginDrag(PointerEventData eventData)
    {
        originalPosition = transform.position;
        GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!GameController.instance.isPlayable)
            return;

        //delta change in position
        transform.position += (Vector3)eventData.delta;
        Card card = GetComponent<Card>();

        Card draggingCard = GetComponent<Card>();
        bool overCard = false;

        foreach (GameObject hover in eventData.hovered)
        {
            Player playerCard = hover.GetComponent<Player>();
            if (playerCard!=null)
            {
                if (GameController.instance.CardValid(draggingCard, playerCard,  GameController.instance.playersHand))
                { //make that card glow
                    playerCard.glowImage.gameObject.SetActive(true);
                    overCard = true;
                   
                }
                    
            }

            BurnZone burnZone = hover.GetComponent<BurnZone>();
            if (burnZone != null)
            {
                card.burnImage.gameObject.SetActive(true);
            }
            else
            {
                card.burnImage.gameObject.SetActive(false);
            }
        }
        if (!overCard)//when were not hoverin over any card
        {
            GameController.instance.player.glowImage.gameObject.SetActive(false);
            GameController.instance.enemy.glowImage.gameObject.SetActive(false);
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        transform.position = originalPosition;
        GetComponent<Card>().burnImage.gameObject.SetActive(false);
        GetComponent<CanvasGroup>().blocksRaycasts = true;

        // Remove card if it was dragged on burn zone
        foreach (GameObject hover in eventData.hovered)
        {
            BurnZone burnZone = hover.GetComponent<BurnZone>();
            if (burnZone != null)
            {
                burnZone.BurnCard(GetComponent<Card>());
            }
        }
    }
}
