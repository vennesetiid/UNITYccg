using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BurnZone : MonoBehaviour
{
    // Not currently working and burning card is done in card's OnEndDrag
    //public void OnDrop(PointerEventData eventData)
    //{
    //    Debug.Log("moi");
    //    GameObject obj = eventData.pointerDrag;
    //    Card card = obj.GetComponent<Card>();
    //    if (card!=null)
    //    {
    //        GameController.instance.playersHand.RemoveCard(card);
    //    }
    //}

    public AudioSource burnAudio = null;

    public void BurnCard(Card card)
    {
        if (card != null)
        {
            PlayBurnSound();
            GameController.instance.playersHand.RemoveCard(card);
            GameController.instance.NextPlayersTurn();
        }
    }

    internal void PlayBurnSound()
    {
        burnAudio.Play();
    }
}